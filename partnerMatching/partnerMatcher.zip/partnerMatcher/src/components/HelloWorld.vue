<script setup lang="ts">





</script>

<template>
  <div>
    <van-button type="primary">主要按钮</van-button>
  </div>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>
