import Index from "../pages/Index.vue";
import Team from "../pages/Team.vue";
import searchPage from "../pages/searchPage.vue";
import UserEdits from "../pages/UserEdits.vue"
import UserPages from "../pages/UserPages.vue"
const routes = [
    { path:"/",redirect:"/Index"},
    { path: '/Index', component: Index },
    { path: '/Team', component: Team },
    { path: '/search', component: searchPage },
    { path: '/UserEdit',name:'/UserEdit', component: UserEdits },
    { path: '/UserPage', component: UserPages },
]
export default routes;