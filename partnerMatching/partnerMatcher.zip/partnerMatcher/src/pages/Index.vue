<script setup lang="ts">

</script>

<template>
首页哦我靠
</template>

<style scoped>

</style>