<script setup lang="ts">

</script>

<template>
队友页面
</template>

<style scoped>

</style>