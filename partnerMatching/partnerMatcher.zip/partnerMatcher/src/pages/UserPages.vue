<script setup lang="ts">

import {useRouter} from "vue-router";

const user = {
  userAccount:'yupi',
  username:'鱼皮',
  gender:'男',
  planetCode:'1234',
  email:'1840854390@qq.com',
  avatarUrl:'https://himg.bdimg.com/sys/portraitn/item/public.1.e137c1ac.yS1WqOXfSWEasOYJ2-0pvQ',
  phone:'18569023503',
  createTime:new Date()
};

const router = useRouter();
const toEdit = (editKey: string, editName: string, editValue: string) => {
  router.push({
    name: '/UserEdit',
    query: {
      editKey,
      editName,
      editValue
    }
  })
}
</script>

<template>
  <van-cell title="昵称" :value="user?.username" />
  <van-cell title="账号" :value="user?.userAccount" @click="toEdit('userAccount','账号',user?.userAccount)"/>
  <van-cell title="性别" :value="user?.gender" />
  <van-cell title="邮箱" :value="user?.email" />
  <van-cell title="电话" :value="user?.phone" />
  <van-cell title="星球编号" :value="user?.planetCode" />
<!--  <van-cell title="注册时间" :value="user?.createTime" />-->
  <van-cell title="头像" :value="user?.avatarUrl" >
    <img :src="user?.avatarUrl"/>
  </van-cell>
</template>

<style scoped>

</style>